package pizzaProject;

public class Pizza {

	private String pizzaName;
	private String pizzaType;
	private int pizzaPrice;
	private String deliveryLocation;
	public String getPizzaName() {
		return pizzaName;
	}
	public void setPizzaName(String pizzaName) {
		this.pizzaName = pizzaName;
	}
	public String getPizzaType() {
		return pizzaType;
	}
	public void setPizzaType(String pizzaType) {
		this.pizzaType = pizzaType;
	}
	public int getPizzaPrice() {
		return pizzaPrice;
	}
	public void setPizzaPrice(int pizzaPrice) {
		this.pizzaPrice = pizzaPrice;
	}
	public String getDeliveryLocation() {
		return deliveryLocation;
	}
	public void setDeliveryLocation(String deliveryLocation) {
		this.deliveryLocation = deliveryLocation;
	}
	public Pizza(String pizzaName, String pizzaType, int pizzaPrice, String deliveryLocation) {
		super();
		this.pizzaName = pizzaName;
		this.pizzaType = pizzaType;
		this.pizzaPrice = pizzaPrice;
		this.deliveryLocation = deliveryLocation;
	}
	@Override
	public String toString() {
		return "Pizza [pizzaName=" + pizzaName + ", pizzaType=" + pizzaType + ", pizzaPrice=" + pizzaPrice
				+ ", DeliveryLocation=" + deliveryLocation + "]";
	}
	
}
