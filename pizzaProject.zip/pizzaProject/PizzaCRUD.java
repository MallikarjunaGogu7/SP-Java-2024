package pizzaProject;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map.Entry;
import java.util.Scanner;
import java.util.Set;


public class PizzaCRUD {

	public static void main(String[] args) {
		
	HashMap<Integer,Pizza> pizza = new HashMap<Integer,Pizza>();
	
	int pizzaId = 420;
		
		while(true) {
			System.out.println("***Pizza Management ***");
			System.out.println("1.Add Pizza");
			System.out.println("2.Update Pizza");
			System.out.println("3.Get Pizza");
			System.out.println("4.Delete Pizza");
			System.out.println("5.Get All Pizza");
			
			Scanner sc = new Scanner(System.in);
			int option = sc.nextInt();
			
			switch(option)
			{
			
			case 1:
				System.out.println("Add Pizza detais");
				System.out.println("Enter The Pizza Name..");
				String pizzaName = sc.next();
				System.out.println("Enter Pizza Type");
				String pizzaType = sc.next();
				System.out.println("Enter Pizza Price");
				int pizzaPrice = sc.nextInt();
				System.out.println("Enter Pizza Deleviry Location");
				String deliveryLocation = sc.next();
				
				Pizza objPizza = new Pizza(pizzaName, pizzaType, pizzaPrice, deliveryLocation);
				
				pizza.put(++pizzaId, objPizza);
				System.out.println("Pizza details added successfully :"+pizzaId);
			break;
			
			case 2:
				System.out.println("Update Pizza detais");
				
				System.out.println("for Update enter pizza id");
				int pId=sc.nextInt();
				System.out.println("Enter Pizza Name..");
				String pName=sc.next();
				System.out.println("Enter Pizza Type");
				String pType = sc.next();
				System.out.println("Enter Pizza Price");
				int pPrice = sc.nextInt();
				System.out.println("Enter Pizza delevery Location");
				String pLoc = sc.next();
				
				Pizza pizza1 = new Pizza(pName, pType,pPrice, pLoc);
				pizza.put(pId, pizza1);
			break;
			
			case 3:
				System.out.println("Get Pizza detais");
				
				System.out.println("Enter pizza id to get details");
				int pId2=sc.nextInt();
				
				Pizza pobj = pizza.get(pId2);
				System.out.println(pobj);

			break;
			
			case 4:
				System.out.println("Delete Pizza detais");
				System.out.println("Enter Pizza id To remove Pizza");
				int pId3 = sc.nextInt();
				
				pizza.remove(pId3);
				System.out.println("Pizza removed successfully :"+pId3);
			break;
			
			case 5:
				System.out.println("Get All Employee details");
				
				Set<Entry<Integer,Pizza>> result = pizza.entrySet();
				Iterator<Entry<Integer,Pizza>> itr = result.iterator();
				
				while (itr.hasNext())
				{
					Entry<Integer,Pizza> finalResult = itr.next();
					System.out.println(finalResult.getKey()+"  "+finalResult.getValue());
				}
			break;
			default:
				System.out.println("no case is matched");
				break;
			
			}
		}
	
		
		
	}
}
