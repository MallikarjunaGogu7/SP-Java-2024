package testArraysAndStrings;
//2. Write a program to array elements print all Even number

import java.util.Scanner;
public class Ex2 {

	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);
		System.out.println("Enter the Array Limit: ");
		int l = input.nextInt();
		int a [] = new int[l];
		for(int i=0; i<l; i++)
		{
			System.out.printf("enter array elements a[%d: ",i);
			a[i] = input.nextInt();
		}
		
		System.out.println("Even Array Elements");
		
		for(int e:a)
		{
			if(e%2==0)
			{
				System.out.println(e);
			}
		}
	}
}
