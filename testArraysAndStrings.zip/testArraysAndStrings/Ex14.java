package testArraysAndStrings;


import java.util.Scanner;

public class Ex14 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Enter the string: ");
        String str = scanner.nextLine();

        System.out.print("Enter the start index: ");
        int startIndex = scanner.nextInt();

        System.out.print("Enter the end index: ");
        int endIndex = scanner.nextInt();

        int codePointCount = str.codePointCount(startIndex, endIndex);

        System.out.println("Number of Unicode code points in the specified range: " + codePointCount);

        scanner.close();
    }
}
