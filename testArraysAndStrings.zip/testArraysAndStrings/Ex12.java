package testArraysAndStrings;
import java.util.Scanner;

//12.Write a program to check whether a given string ends with the contents of
//another string
public class Ex12 {

	public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Input first string
        System.out.print("Enter the main string: ");
        String mainString = scanner.nextLine();

        // Input the string to check if it is at the end
        System.out.print("Enter the string to check: ");
        String checkString = scanner.nextLine();

        // Check if the main string ends with the check string
        if (mainString.endsWith(checkString)) {
            System.out.println("The main string ends with the given string.");
        } else {
            System.out.println("The main string does NOT end with the given string.");
        }

        scanner.close();
    }
}
