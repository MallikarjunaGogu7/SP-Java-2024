package testArraysAndStrings;
//4. Write a program to search an element in an array
import java.util.Scanner;
public class Ex4 {

	 public static void main(String[] args) {
	        Scanner input = new Scanner(System.in);
	        System.out.print("enter the limit of array : ");
	        int l = input.nextInt();
	        int a [] = new int[l];
	        for(int i=0;i<l;i++)
	        {
	            System.out.printf("Element of a[%d] :",i);
	            a[i] = input.nextInt();
	        }
	        System.out.println("Enter the Search Array Element :");
	        int s = input.nextInt();
	        int i,f=0;
	        for( i=0; i<l; i++)
	        {
	            if(a[i]==s)
	            {
	                f=1;
	                break;
	            }
	        }
	        if(f==1)
	        {
	            System.out.printf("\nThe Element is found in the Index : %d", i);
	        }
	        else{
	            System.out.println("The Element Is Not Found");
	        }

	    }
}
