package testArraysAndStrings;
// 5. Write a program to array elements to print sum of Negative Numbers
import java.util.Scanner;
public class Ex5 {

	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);
		System.out.println("Enter the Array Limit: ");
        int l = input.nextInt();
        int a [] = new int[l];
        int sum = 0;
        for (int i=0; i<l; i++)
        {
            System.out.printf("Elements of a[%d]: ",i);
            a[i] = input.nextInt();
        }
        
        for (int n: a)
        {
        	if (n<0)
        	{
        		sum += n;
        	}
        	System.out.println("sum of negative Array Elements is: "+ sum);
        }
	}
}
