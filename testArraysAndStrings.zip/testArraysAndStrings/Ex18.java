package testArraysAndStrings;

//18.Write a program to create a character array containing the contents of a string

import java.util.Scanner;
public class Ex18 {

	public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Enter a string: ");
        String input = scanner.nextLine();

        char[] charArray = input.toCharArray();

        System.out.println("Character array: ");
        for (char c : charArray) {
            System.out.print(c + " ");
        }

        scanner.close();
    }
}


