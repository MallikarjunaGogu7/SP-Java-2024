package testArraysAndStrings;
//10.Write a program to merge two arrays elements to store third array

import java.util.Scanner;
public class Ex10{
	public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        
        // Input sizes of the arrays
        System.out.print("Enter the size of the first array: ");
        int size1 = scanner.nextInt();
        System.out.print("Enter the size of the second array: ");
        int size2 = scanner.nextInt();
        
        // Initialize the arrays
        int[] array1 = new int[size1];
        int[] array2 = new int[size2];
        int[] mergedArray = new int[size1 + size2];
        
        // Input elements for the first array
        System.out.println("Enter elements of the first array:");
        for (int i = 0; i < size1; i++) {
            System.out.print("Element " + (i + 1) + ": ");
            array1[i] = scanner.nextInt();
        }

        // Input elements for the second array
        System.out.println("Enter elements of the second array:");
        for (int i = 0; i < size2; i++) {
            System.out.print("Element " + (i + 1) + ": ");
            array2[i] = scanner.nextInt();
        }
        
        // Merge the two arrays into the third array
        for (int i = 0; i < size1; i++) {
            mergedArray[i] = array1[i];
        }
        for (int i = 0; i < size2; i++) {
            mergedArray[size1 + i] = array2[i];
        }
        
        // Display the merged array
        System.out.println("Merged Array:");
        for (int i = 0; i < mergedArray.length; i++) {
            System.out.print(mergedArray[i] + " ");
        }
        
        scanner.close();
    }
}


