package testArraysAndStrings;
import java.util.Scanner;

//8. Write a program to calculate the average value of array elements
public class Ex8 {

	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);
        System.out.println("Enter the Arrray Limit: ");
        int l = input.nextInt();
        int a [] = new int[l];
        int sum = 0;
        for (int i = 0; i < l; i++)
        {
            System.out.printf("\nElements of a[%d]: ",i);
            a[i] =input.nextInt();
        }
        
        for (int i = 0; i<l; i++)
        {
        	sum += a[i];
        }
        
        double avg = sum /l;
        System.out.println("the Average of Array Elements is: "+ avg);
	}
}
