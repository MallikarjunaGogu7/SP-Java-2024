package testArraysAndStrings;
import java.util.Scanner;
//1. Write a program to copy the elements of one array into another array
public class Ex1 {

	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);
		System.out.println("Enter the array limit: ");
		int l = input.nextInt();
		int a[] = new int[l];
		int c[] = new int[l];
		
		for(int i=0; i<l; i++)
		{
			System.out.printf(" Element of a[%d] :",i);
			a[i] = input.nextInt();
		}
		
		for(int i=0; i<l; i++)
		{
			c[i] = a[i];
		}
		
		System.out.println("original array Elements..");
		for(int i=0; i<l; i++)
		{
			System.out.printf("\na[%d] = %d",i,a[i]);
			
		}
		System.out.println("copied array Elements..");
		for(int i=0; i<l; i++)
		{
			System.out.printf("\nc[%d] = %d",i,c[i]);
			
		}
		
	}
	
}
