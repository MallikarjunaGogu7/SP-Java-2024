package testArraysAndStrings;
//19.Write a program to find maximum between two string
import java.util.Scanner;
public class Ex19 {

	public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Enter the first string: ");
        String str1 = scanner.nextLine();

        System.out.print("Enter the second string: ");
        String str2 = scanner.nextLine();

        String maxString = str1.compareTo(str2) > 0 ? str1 : str2;

        System.out.println("The maximum string is: " + maxString);

        scanner.close();
    }
}
