package testArraysAndStrings;
//write a program to array elements to print all odd numbers
import java.util.Scanner;

public class Ex3 {
	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);
		System.out.println("Enter the Array Limit: ");
		int l = input.nextInt();
		int a [] = new int[l];
		for(int i=0; i<l; i++)
		{
			System.out.printf("enter array elements a[%d: ",i);
			a[i] = input.nextInt();
		}
		
		System.out.println("odd Array Elements");
		
		for(int o:a)
		{
			if(o%2!=0)
			{
				System.out.println(o);
			}
		}
	}
}
