package testArraysAndStrings;

import java.util.Scanner;
public class Ex15 {
	
	public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Enter the string: ");
        String str = scanner.nextLine();

        System.out.print("Enter the character sequence: ");
        StringBuilder charSequence = new StringBuilder(scanner.nextLine());

        if (str.contentEquals(charSequence)) {
            System.out.println("The string is equal to the specified character sequence.");
        } else {
            System.out.println("The string is NOT equal to the specified character sequence.");
        }

        scanner.close();
    }
}


