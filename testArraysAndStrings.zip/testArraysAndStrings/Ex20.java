package testArraysAndStrings;
//20.Write a program to create a new string repeating every character twice of a given string

import java.util.Scanner;
public class Ex20 {

	public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Enter a string: ");
        String input = scanner.nextLine();
        
        StringBuilder repeatedString = new StringBuilder();

        for (char c : input.toCharArray()) {
            repeatedString.append(c).append(c);
        }

        System.out.println("New string with each character repeated twice: " + repeatedString.toString());

        scanner.close();
    }
}


