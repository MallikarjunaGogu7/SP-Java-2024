package testArraysAndStrings;
import java.util.Scanner;
public class Ex13 {

	public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Enter the first string: ");
        String str1 = scanner.nextLine();

        System.out.print("Enter the second string: ");
        String str2 = scanner.nextLine();

        if (str1.equals(str2)) {
            System.out.println("The two strings contain the same data.");
        } else {
            System.out.println("The two strings do not contain the same data.");
        }

        scanner.close();
    }
}


