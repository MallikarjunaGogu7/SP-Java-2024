package testArraysAndStrings;
import java.util.Scanner;
//9. Write a program in to find the sum of all elements of the array
public class Ex9 {

	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);
        System.out.println("Enter the Arrray Limit: ");
        int l = input.nextInt();
        int a [] = new int[l];
        int sum = 0;
        for (int i = 0; i < l; i++)
        {
            System.out.printf("\nElements of a[%d]: ",i);
            a[i] =input.nextInt();
        }
        
        for( int i=0; i<l; i++)
        {
        	sum += a[i];
        }
        System.out.println("The sum of all Elements of array Is: "+sum);
	}
}
