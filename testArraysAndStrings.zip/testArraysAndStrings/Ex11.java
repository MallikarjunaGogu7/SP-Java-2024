package testArraysAndStrings;
//11.Write a program to get the canonical representation of the string object
public class Ex11 {
	
	    public static void main(String[] args) {
	        // Two string objects with the same content, but created differently
	        String str1 = new String("HelloWorld");
	        String str2 = new String("HelloWorld");
	        
	        // Checking references without using intern()
	        System.out.println("Before interning:");
	        System.out.println("Are str1 and str2 the same object? " + (str1 == str2));

	        // Getting canonical representation (interning)
	        String canonicalStr1 = str1.intern();
	        String canonicalStr2 = str2.intern();
	        
	        // Checking references after using intern()
	        System.out.println("\nAfter interning:");
	        System.out.println("Are canonicalStr1 and canonicalStr2 the same object? " + (canonicalStr1 == canonicalStr2));
	        System.out.println("Canonical representation of str1: " + canonicalStr1);
	    }
	
}
