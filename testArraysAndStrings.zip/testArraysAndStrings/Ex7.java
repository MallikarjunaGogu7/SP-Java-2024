package testArraysAndStrings;
import java.util.Scanner;

//7. Write a program to array elements print all Positive number

public class Ex7 {

	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);
		System.out.println("Enter the Array Limit: ");
		int l = input.nextInt();
		
		int a [] = new int[l];
		
		for (int i = 0; i<l; i++)
        {
            System.out.printf("Elements of a[%d] : ",i);
            a[i] = input.nextInt();
        }
		
		for(int p:a)
		{
			if (p>0)
			{
				System.out.println(p);
			}
		}
	}
}
